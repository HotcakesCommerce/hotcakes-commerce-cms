UPDATE {databaseOwner}{objectQualifier}HostSettings
	SET SettingValue='DesktopModules/Hotcakes/ControlPanel/ControlBar.ascx'
	WHERE SettingName='ControlPanel'
GO